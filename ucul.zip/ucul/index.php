<?php
// Silence is golden. | Diam itu emas, tapi gue udah diem terus kok ga dapet2 emasnya? =))
?>